const inputArea = document.getElementById('inputArea');
const screen = document.getElementById('screen');

function addToInput(value) {
    if (inputArea.value) {
        inputArea.value += ' ';
    }
    inputArea.value += value;
}

function submitInput() {
    const inputText = inputArea.value;
    if (inputText) {
        screen.textContent = inputText;
        inputArea.value = '';
    }
}

const screen = document.getElementById('screen');

function updateScreen(logs) {
    screen.textContent = logs;
}

async function fetchGameStatus() {
    const response = await fetch('http://localhost:8080/api/game/status');
    const status = await response.json();
    updateScreen(JSON.stringify(status, null, 2));
}

async function playTurn() {
    await fetch('http://localhost:8080/api/game/playTurn', { method: 'POST' });
    fetchGameStatus();
}