package org.example.cards;

public enum EventType {
    PLAGUE,
    QUEENS_FAVOR,
    PROSPERITY
}