package org.example.cards;

import org.example.Card;

public class FoeCard extends Card {
    public FoeCard(int value) {
        super("F" + value, value);
    }
}